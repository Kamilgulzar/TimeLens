const KEY = "timelens:store";
export const DEFAULT_STORE = {
    auth: null,
    trackingEnabled: false,
    session: null,
    error: null,
    syncing: false,
};
function isStore(v) {
    if (!v || typeof v !== "object")
        return false;
    const s = v;
    return (typeof s.trackingEnabled === "boolean" &&
        typeof s.syncing === "boolean" &&
        ("session" in s) &&
        ("auth" in s) &&
        ("error" in s));
}
export async function readStore() {
    const data = await chrome.storage.local.get(KEY);
    if (isStore(data[KEY])) {
        return data[KEY];
    }
    return { ...DEFAULT_STORE };
}
export async function writeStore(store) {
    await chrome.storage.local.set({ [KEY]: store });
}
export async function clearStore() {
    await chrome.storage.local.remove(KEY);
}

import { API_BASE_URL } from "../lib/config.js";
function toApiError(message, extra = {}) {
    const err = new Error(message);
    Object.assign(err, extra);
    return err;
}
async function request(path, init = { method: "GET" }) {
    let response;
    try {
        response = await fetch(`${API_BASE_URL}${path}`, {
            method: init.method,
            headers: {
                ...(init.body !== undefined ? { "Content-Type": "application/json" } : {}),
                ...(init.token ? { Authorization: `Bearer ${init.token}` } : {}),
            },
            body: init.body !== undefined ? JSON.stringify(init.body) : undefined,
        });
    }
    catch {
        throw toApiError("Unable to reach the TimeLens server.", { network: true });
    }
    if (!response.ok) {
        let payload = null;
        try {
            payload = await response.json();
        }
        catch {
            // Non-JSON error body.
        }
        const message = payload && typeof payload === "object" && "error" in payload
            ? String(payload.error)
            : `TimeLens server responded with ${response.status}.`;
        throw toApiError(message, { status: response.status, payload });
    }
    if (response.status === 204) {
        return undefined;
    }
    return response.json();
}
export const timelensApi = {
    extensionLogin(email, password) {
        return request("/auth/extension-login", {
            method: "POST",
            body: { email, password, source: "browser" },
        });
    },
    extensionOAuthLogin(provider, email, firstName, lastName, avatar) {
        return request("/auth/extension-oauth", {
            method: "POST",
            body: { provider, email, firstName, lastName, avatar },
        });
    },
    submitActivities(token, events) {
        return request("/activities", {
            method: "POST",
            token,
            body: { events },
        });
    },
    activitySummary(token, from, to) {
        const params = new URLSearchParams({ from, to });
        return request(`/activities/summary?${params.toString()}`, {
            method: "GET",
            token,
        });
    },
    extensionHeartbeat(token, body) {
        return request("/activities/heartbeat", {
            method: "POST",
            token,
            body,
        });
    },
    extensionPending(token) {
        return request("/activities/extension-control/pending", {
            method: "GET",
            token,
        });
    },
    extensionAck(token) {
        return request("/activities/extension-control/ack", {
            method: "POST",
            token,
        });
    },
};
